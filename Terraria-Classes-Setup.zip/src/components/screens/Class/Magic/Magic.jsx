

export const Magic = () => {
  return (
    <div>Magic</div>
  )
}
